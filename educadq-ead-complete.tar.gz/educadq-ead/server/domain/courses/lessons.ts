import { TRPCError } from "@trpc/server";
import { protectedProcedure, router } from "../../_core/trpc";
import {
  createLesson,
  getLessonsByCourse,
  getLessonsByModule,
  getLessonById,
  updateLesson,
  deleteLesson,
  getCourseById,
  getModuleById,
  createLessonMaterial,
  getMaterialsByLesson,
  deleteLessonMaterial,
  createModule,
  getModulesByCourse,
  updateModule,
  deleteModule,
} from "../../infra/db";
import { z } from "zod";

export const lessonsRouter = router({
  // ===== MODULES =====
  getModulesByCourse: protectedProcedure
    .input(z.object({ courseId: z.number() }))
    .query(async ({ input }: any) => {
      return await getModulesByCourse(input.courseId);
    }),

  createModule: protectedProcedure
    .input(z.object({
      courseId: z.number(),
      title: z.string().min(1),
      description: z.string().optional(),
      order: z.number().min(1),
    }))
    .mutation(async ({ input, ctx }: any) => {
      const course = await getCourseById(input.courseId);
      if (!course) throw new TRPCError({ code: "NOT_FOUND", message: "Curso nao encontrado" });
      if (ctx.user?.role !== "admin" && ctx.user?.id !== course.professorId) {
        throw new TRPCError({ code: "FORBIDDEN", message: "Sem permissao" });
      }
      return await createModule(input);
    }),

  updateModule: protectedProcedure
    .input(z.object({
      moduleId: z.number(),
      title: z.string().optional(),
      description: z.string().optional(),
      order: z.number().optional(),
    }))
    .mutation(async ({ input, ctx }: any) => {
      const mod = await getModuleById(input.moduleId);
      if (!mod) throw new TRPCError({ code: "NOT_FOUND", message: "Modulo nao encontrado" });
      const course = await getCourseById(mod.courseId);
      if (ctx.user?.role !== "admin" && ctx.user?.id !== course?.professorId) {
        throw new TRPCError({ code: "FORBIDDEN", message: "Sem permissao" });
      }
      const { moduleId, ...data } = input;
      return await updateModule(moduleId, data);
    }),

  deleteModule: protectedProcedure
    .input(z.object({ moduleId: z.number() }))
    .mutation(async ({ input, ctx }: any) => {
      const mod = await getModuleById(input.moduleId);
      if (!mod) throw new TRPCError({ code: "NOT_FOUND", message: "Modulo nao encontrado" });
      const course = await getCourseById(mod.courseId);
      if (ctx.user?.role !== "admin" && ctx.user?.id !== course?.professorId) {
        throw new TRPCError({ code: "FORBIDDEN", message: "Sem permissao" });
      }
      return await deleteModule(input.moduleId);
    }),

  // ===== LESSONS =====
  getByCourse: protectedProcedure
    .input(z.object({ courseId: z.number() }))
    .query(async ({ input }: any) => {
      return await getLessonsByCourse(input.courseId);
    }),

  getByModule: protectedProcedure
    .input(z.object({ moduleId: z.number() }))
    .query(async ({ input }: any) => {
      return await getLessonsByModule(input.moduleId);
    }),

  getById: protectedProcedure
    .input(z.object({ lessonId: z.number() }))
    .query(async ({ input }: any) => {
      const lesson = await getLessonById(input.lessonId);
      if (!lesson) throw new TRPCError({ code: "NOT_FOUND", message: "Aula nao encontrada" });
      const materials = await getMaterialsByLesson(input.lessonId);
      return { ...lesson, materials };
    }),

  create: protectedProcedure
    .input(z.object({
      moduleId: z.number(),
      title: z.string().min(1),
      description: z.string().optional(),
      type: z.enum(["video", "text", "live", "material"]),
      content: z.string().optional(),
      videoUrl: z.string().optional(),
      liveUrl: z.string().optional(),
      order: z.number().min(1),
      durationMinutes: z.number().optional(),
    }))
    .mutation(async ({ input, ctx }: any) => {
      console.log("[LESSON CREATE] Mutation called");
      console.log("[LESSON CREATE] Input:", input);
      console.log("[LESSON CREATE] User:", ctx.user);
      
      const mod = await getModuleById(input.moduleId);
      console.log("[LESSON CREATE] Module found:", mod);
      if (!mod) throw new TRPCError({ code: "NOT_FOUND", message: "Modulo nao encontrado" });
      
      const course = await getCourseById(mod.courseId);
      console.log("[LESSON CREATE] Course found:", course);
      
      if (ctx.user?.role !== "admin" && ctx.user?.id !== course?.professorId) {
        console.log("[LESSON CREATE] Permission denied");
        throw new TRPCError({ code: "FORBIDDEN", message: "Sem permissao" });
      }
      
      console.log("[LESSON CREATE] Creating lesson...");
      const result = await createLesson(input);
      console.log("[LESSON CREATE] Lesson created:", result);
      return result;
    }),

  update: protectedProcedure
    .input(z.object({
      lessonId: z.number(),
      title: z.string().optional(),
      description: z.string().optional(),
      type: z.enum(["video", "text", "live", "material"]).optional(),
      content: z.string().optional(),
      videoUrl: z.string().optional(),
      liveUrl: z.string().optional(),
      order: z.number().optional(),
      durationMinutes: z.number().optional(),
    }))
    .mutation(async ({ input, ctx }: any) => {
      const lesson = await getLessonById(input.lessonId);
      if (!lesson) throw new TRPCError({ code: "NOT_FOUND", message: "Aula nao encontrada" });
      const mod = await getModuleById(lesson.moduleId);
      if (!mod) throw new TRPCError({ code: "NOT_FOUND", message: "Modulo nao encontrado" });
      const course = await getCourseById(mod.courseId);
      if (ctx.user?.role !== "admin" && ctx.user?.id !== course?.professorId) {
        throw new TRPCError({ code: "FORBIDDEN", message: "Sem permissao" });
      }
      const { lessonId, ...data } = input;
      return await updateLesson(lessonId, data);
    }),

  delete: protectedProcedure
    .input(z.object({ lessonId: z.number() }))
    .mutation(async ({ input, ctx }: any) => {
      const lesson = await getLessonById(input.lessonId);
      if (!lesson) throw new TRPCError({ code: "NOT_FOUND", message: "Aula nao encontrada" });
      return await deleteLesson(input.lessonId);
    }),

  // ===== MATERIALS =====
  addMaterial: protectedProcedure
    .input(z.object({
      lessonId: z.number(),
      title: z.string().min(1),
      type: z.enum(["pdf", "document", "spreadsheet", "video", "link"]).default("link"),
      url: z.string().url(),
      fileSize: z.number().optional(),
    }))
    .mutation(async ({ input, ctx }: any) => {
      const lesson = await getLessonById(input.lessonId);
      if (!lesson) throw new TRPCError({ code: "NOT_FOUND", message: "Aula nao encontrada" });
      return await createLessonMaterial(input);
    }),

  removeMaterial: protectedProcedure
    .input(z.object({ materialId: z.number() }))
    .mutation(async ({ input }: any) => {
      return await deleteLessonMaterial(input.materialId);
    }),

  getMaterials: protectedProcedure
    .input(z.object({ lessonId: z.number() }))
    .query(async ({ input }: any) => {
      return await getMaterialsByLesson(input.lessonId);
    }),
});
