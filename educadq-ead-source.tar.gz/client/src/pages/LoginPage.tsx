import SEO from "@/components/SEO";
import { useEffect } from "react";
import { useAuth } from "@/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { Loader2, BookOpen } from "lucide-react";
import { useLocation } from "wouter";

export default function LoginPage() {
  const { user, loading } = useAuth();
  const [, setLocation] = useLocation();

  useEffect(() => {
    if (!loading && user) {
      // Já está logado, redirecionar para o dashboard apropriado
      if (user.role === "admin") {
        setLocation("/admin");
      } else {
        setLocation("/student");
      }
    }
  }, [user, loading, setLocation]);

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-background">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (user) {
    return null; // useEffect vai redirecionar
  }

  return (
    <>
    <SEO title="Login" description="Acesse sua conta na plataforma EducaDQ para acessar cursos, aulas e materiais de estudo." />
    <div className="flex items-center justify-center min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      <div className="w-full max-w-md mx-4">
        <div className="bg-card rounded-2xl shadow-2xl p-8 border border-border">
          {/* Logo */}
          <div className="flex flex-col items-center mb-8">
            <div className="w-16 h-16 bg-primary/10 rounded-2xl flex items-center justify-center mb-4">
              <BookOpen className="h-8 w-8 text-primary" />
            </div>
            <h1 className="text-2xl font-bold text-foreground">EducaDQ</h1>
            <p className="text-sm text-muted-foreground mt-1">
              Plataforma de Educação a Distância
            </p>
          </div>

          {/* Descrição */}
          <div className="text-center mb-8">
            <h2 className="text-lg font-semibold text-foreground mb-2">
              Acesse sua conta
            </h2>
            <p className="text-sm text-muted-foreground">
              Entre para acessar seus cursos, aulas e materiais de estudo.
            </p>
          </div>

          {/* Botão de Login */}
          <a
            href={getLoginUrl()}
            className="w-full flex items-center justify-center gap-2 bg-primary hover:bg-primary/90 text-primary-foreground font-medium py-3 px-4 rounded-lg transition-colors"
          >
            Entrar na Plataforma
          </a>

          {/* Informações adicionais */}
          <div className="mt-6 text-center">
            <p className="text-xs text-muted-foreground">
              Centro de Formação e Estudos sobre Álcool e outras Drogas LTDA
            </p>
          </div>
        </div>
      </div>
    </div>
    </>
  );
}
